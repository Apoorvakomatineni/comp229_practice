module.exports =
{
   // "URI": "mongodb://localhost/business_store"
   "URI": "mongodb+srv://Apoorva:28092000@cluster0.h31zy.mongodb.net/test"
}